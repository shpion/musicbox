module Devise
  module Async
    VERSION = "0.9.0"
  end
end
