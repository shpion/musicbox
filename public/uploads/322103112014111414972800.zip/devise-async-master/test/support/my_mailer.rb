class MyMailer < Devise::Mailer
end
